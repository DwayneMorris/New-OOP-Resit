using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace OP_1_Resit
{
    public List<card> DealsCards(int numCards);
    {
        case 1:
        if (numCards > cards.Count)
        {
            throw new ArgumentException("Not right amount of cards in the deck")

        }
        case 2:
            for (int i = 0; i < numCards; i++), (int j = 0; j < numCards; j++)
            {
                Card card = cards[0]
                cards.RemoveAt(0)
                dealtCards.Add(card);
            }
        return dealtCards;
    }

    class Dealing
    {
        static void Main(string[] args)
        {
            Deck deck = new Deck()
            list<Card> dealtCards = deck.DealsCards(3);

            Console.WriteLine("Dealt cards:");
            foreach (var card in dealtCards)
            {
                Console.WriteLine(card);
            }
        }
    }
}