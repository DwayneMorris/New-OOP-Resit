﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text


namespace OOP_1_Resit
{
	 public class Deck
    {
        public card[] Deck; 
        public int index;
        Deck =  new card[52];
        for (int i = 0; i < 14 ; i++),(int j = 0; j < 5 ;  j++ )
        {
            card temp = new card ();
			temp.vaule=i;
			temp.suit=j
			Deck[index] = temp
            index++;
          
        }

     
     public class card 
     {
        public string Suit { get; set;}
        public string Rank { get; set;}

        public override string Tostring()
        {
            return $"{i} of {j}";
        }
     }
    
    
    
    
    
    
    
    }
}
