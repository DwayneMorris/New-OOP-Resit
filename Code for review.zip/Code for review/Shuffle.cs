 using System;
 using System.Text;
 using System.Linq;
 using System.Collections.Generic;
 
 
 
 namespace OP_1_Resit
{
     static public class Shuffle 
     {
        static Random r = new Random ();
        
        static public void Shuffle(int[] deck)
        {
            for (int n = deck.length - 1; n > 0; --n)
            {
                int k = r.Next(n+1);
                int temp = deck[n];
                deck[n] = deck[k]
                deck[k] = temp
            }
            

            
        }

     }

}
